"""Offline checks of transcribed notebook logic. No pretrained models or downloads.
Run from this directory with Python, NumPy, Pillow, PyTorch, SafeTensors and matplotlib.
Synthetic images test parsing, not task accuracy. Synthetic features test probes,
not visual representation quality. All archive/path probes stay inside a temporary directory.
"""
import contextlib, copy, csv, hashlib, io, json, os, platform, shutil, tempfile
from pathlib import Path
import importlib.metadata
import numpy as np
from PIL import Image
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import notebook_excerpts as nb

HERE=Path(__file__).resolve().parent
RESULTS=HERE/'results'; RESULTS.mkdir(exist_ok=True)
records=[]
torch.set_num_threads(1)

def record(name, evidence):
    records.append({'check':name, **evidence})

@contextlib.contextmanager
def cwd(path):
    old=Path.cwd(); Path(path).mkdir(parents=True,exist_ok=True); os.chdir(path)
    try: yield
    finally: os.chdir(old)

def expect_error(fn):
    try: fn()
    except Exception as exc: return f'{type(exc).__name__}: {exc}'
    raise AssertionError('Expected rejection did not occur')

def write_table(root, rows):
    with (root/'labels.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['filename','label','split']); w.writeheader(); w.writerows(rows)

def fixture(root, nested=False):
    root.mkdir(parents=True)
    rows=[]
    for c,label in enumerate(['001','NA']):
        for j in range(30):
            split='train' if j<20 else ('validation' if j<25 else 'test')
            name=('images/' if nested else '')+f'c{c}_{j:02d}.png'
            p=root/name; p.parent.mkdir(parents=True,exist_ok=True)
            i=c*30+j
            Image.new('RGB',(12,12),(i, (i*3)%255, (i*7)%255)).save(p)
            rows.append({'filename':name,'label':label,'split':split})
    write_table(root,rows)
    return rows

def make_zip(root, output, omit=(), extras=()):
    with nb.zipfile.ZipFile(output,'w') as z:
        for p in sorted(root.rglob('*')):
            if p.is_file() and p.relative_to(root).as_posix() not in omit:
                z.write(p,p.relative_to(root).as_posix())
        for name,data in extras: z.writestr(name,data)

def counts(out): return {k:len(v) for k,v in sorted(out.items())}

# 1–2. Both functions' intended tie rule versus what the actual evaluator scores.
cos=np.array([.99,.98,.80,.70,.60])
train=np.column_stack([cos,np.sqrt(1-cos*cos)]); query=np.array([[1.,0.]])
y=np.array([1,1,0,0,2])
pred,probs=nb.knn_predict(train,y,query,5)
metrics=nb.classification_metrics([1],probs)
byod_probs=nb.generic_knn_predict(train,y,query,3,5)
assert pred.tolist()==[1] and metrics['predicted_ids'].tolist()==[0]
assert int(byod_probs.argmax(1)[0])==0
record('knn_tie_decision_mismatch',{
 'kind':'reproduced defect','neighbor_cosines':cos.tolist(),'neighbor_labels':y.tolist(),
 'intended_label':1,'returned_label':int(pred[0]),'scored_label':int(metrics['predicted_ids'][0]),
 'vote_fractions':probs[0].tolist(),'scored_accuracy':metrics['accuracy'],
 'accuracy_under_returned_decision':1.0,'byod_scored_label':int(byod_probs.argmax(1)[0])})
pred,probs=nb.knn_predict(train,np.array([1,1,1,0,2]),query,5)
assert pred.tolist()==[1] and nb.classification_metrics([1],probs)['accuracy']==1
record('knn_unique_majority_control',{'kind':'positive control','returned_and_scored_label':1})

with tempfile.TemporaryDirectory(prefix='modern_image_review_') as tmp:
    root=Path(tmp)
    flat=root/'flat'; rows=fixture(flat)
    out,labels=nb.load_byod_explicit(flat)
    assert counts(out)=={'test':10,'train':40,'validation':10} and labels==['001','NA']
    record('byod_explicit_directory_control',{'kind':'positive control','labels':labels,'counts':counts(out)})
    flat_zip=root/'flat.zip'; make_zip(flat,flat_zip)
    with cwd(root/'zip_good'):
        out,labels=nb.load_byod_explicit(flat_zip)
        assert sum(map(len,out.values()))==60
    record('byod_flat_zip_control',{'kind':'positive control','accepted_images':60})

    nested=root/'nested'; fixture(nested,nested=True)
    out,_=nb.load_byod_explicit(nested); assert sum(map(len,out.values()))==60
    nested_zip=root/'nested.zip'; make_zip(nested,nested_zip)
    with cwd(root/'zip_nested'):
        error=expect_error(lambda:nb.load_byod_explicit(nested_zip))
    record('byod_nested_directory_vs_zip',{'kind':'reproduced defect','directory_images':60,'zip_error':error})

    victim=rows[0]['filename']
    buf=io.BytesIO(); Image.new('RGB',(12,12),(250,241,239)).save(buf,format='PNG')
    overwrite_zip=root/'overwrite.zip'
    make_zip(flat,overwrite_zip,extras=[('unreferenced/'+victim,buf.getvalue())])
    with cwd(root/'zip_collision'):
        out,_=nb.load_byod_explicit(overwrite_zip)
        victim_record=next(r for r in out['train'] if r['source_id']==victim)
        assert victim_record['pixel_sha256']==nb.image_digest(Image.open(io.BytesIO(buf.getvalue())))
    record('byod_duplicate_basename_overwrite',{'kind':'reproduced defect','accepted_images':60,
      'referenced_member':victim,'overwriting_member':'unreferenced/'+victim,
      'loaded_unreferenced_image_instead':True})

    missing_zip=root/'missing.zip'; make_zip(flat,missing_zip,omit=[victim])
    with cwd(root/'stale_workspace'):
        nb.load_byod_explicit(flat_zip)
        out,_=nb.load_byod_explicit(missing_zip)
        stale_accept=sum(map(len,out.values()))
    with cwd(root/'fresh_workspace'):
        error=expect_error(lambda:nb.load_byod_explicit(missing_zip))
    record('byod_zip_rerun_stale_file',{'kind':'reproduced defect','missing_member':victim,
      'accepted_after_prior_zip':stale_accept,'fresh_workspace_error':error})

    escaped=root/'escape_dataset'; shutil.copytree(flat,escaped)
    outside=root/'outside.png'; Image.new('RGB',(12,12),(245,249,251)).save(outside)
    outside_rows=copy.deepcopy(rows); outside_rows[0]['filename']='../outside.png'
    write_table(escaped,outside_rows)
    out,_=nb.load_byod_explicit(escaped)
    escaped_record=next(r for r in out['train'] if r['source_id']=='../outside.png')
    assert escaped_record['pixel_sha256']==nb.image_digest(Image.open(outside))
    record('byod_csv_path_escapes_dataset',{'kind':'reproduced defect','accepted_images':60,
       'relative_filename':'../outside.png','outside_image_read':True,
       'safety':'all files generated inside this temporary probe directory'})

    bad=root/'bad'; shutil.copytree(flat,bad)
    (bad/'labels.csv').write_text('filename,split\nc0_00.png,train\n')
    missing_label=expect_error(lambda:nb.load_byod_explicit(bad))
    duplicate=root/'duplicate'; shutil.copytree(flat,duplicate)
    dup_rows=copy.deepcopy(rows); dup_rows[20]['filename']=dup_rows[0]['filename']
    write_table(duplicate,dup_rows)
    duplicate_error=expect_error(lambda:nb.load_byod_explicit(duplicate))
    unsafe_zip=root/'unsafe.zip'
    with nb.zipfile.ZipFile(unsafe_zip,'w') as z: z.writestr('../escape.txt','synthetic')
    with cwd(root/'unsafe_zip_workspace'):
        unsafe_error=expect_error(lambda:nb.load_byod_explicit(unsafe_zip))
    record('byod_rejection_controls',{'kind':'positive controls','missing_label':missing_label,
      'cross_split_duplicate':duplicate_error,'zip_traversal_member':unsafe_error})

    # Real CPU fitting and serialized tensor reload, synthetic feature vectors only.
    rng=np.random.default_rng(420)
    yt=np.repeat(np.arange(6),6); yv=np.repeat(np.arange(6),2)
    tr=np.eye(6,dtype=np.float32)[yt]+rng.normal(0,.02,(36,6)).astype(np.float32)
    va=np.eye(6,dtype=np.float32)[yv]+rng.normal(0,.02,(12,6)).astype(np.float32)
    te=np.eye(6,dtype=np.float32)[yv]+rng.normal(0,.02,(12,6)).astype(np.float32)
    probe=nb.fit_probe(tr,yt,va,yv,te,epochs=100)
    probe_changed_test=nb.fit_probe(tr,yt,va,yv,te+25,epochs=100)
    assert np.array_equal(probe['mean'],probe_changed_test['mean'])
    assert probe['best_epoch']==probe_changed_test['best_epoch']
    assert all(torch.equal(probe['layer'].state_dict()[k],probe_changed_test['layer'].state_dict()[k]) for k in ['weight','bias'])
    record('train_only_normalization_and_selection',{'kind':'positive control','same_weights_after_test_input_change':True,
      'same_best_epoch':probe['best_epoch'],'same_training_statistics':True,'backbone':'not executed'})
    nb.OUT_ROOT=root/'artifacts'
    spec={'manifest':{'modelId':'review/synthetic-feature-source','revision':'a'*40,
      'files':[{'path':'model.safetensors','sha256':'b'*64}]}}
    path,manifest=nb.save_probe_artifact('synthetic',spec,probe,6,'train-fixture','validation-fixture')
    parity=nb.reload_probe_verify(path,manifest,spec,te,probe['test_probs'])
    assert parity<=1e-6
    bad_spec=copy.deepcopy(spec); bad_spec['manifest']['revision']='c'*40
    identity_error=expect_error(lambda:nb.reload_probe_verify(path,manifest,bad_spec,te,probe['test_probs']))
    record('artifact_serialized_reload_control',{'kind':'positive control','cpu_probe_training':True,
      'reload_max_abs_probability_difference':parity,'base_revision_rejection':identity_error})
    bad_manifest=copy.deepcopy(manifest); bad_manifest['class_order']=list(reversed(nb.CLASS_KEYS))
    bad_manifest['probe_file']['sha256']='0'*64
    (path.parent/'manifest.json').write_text(json.dumps(bad_manifest))
    using_original=nb.reload_probe_verify(path,manifest,spec,te,probe['test_probs'])
    using_changed=nb.reload_probe_verify(path,bad_manifest,spec,te,probe['test_probs'])
    ids=probe['test_probs'].argmax(1)
    remapped=sum(nb.CLASS_KEYS[i]!=bad_manifest['class_order'][i] for i in ids)
    assert remapped==12 and using_changed==0
    record('artifact_manifest_semantics_not_verified',{'kind':'reproduced defect',
      'on_disk_manifest_changed_but_original_dict_passes':using_original,
      'reversed_class_order_and_wrong_digest_dict_passes':using_changed,
      'semantic_label_changes_under_reversed_class_order':int(remapped),
      'held_out_rows':12})

# The optional control cell, exact body transcribed (cell 23084f05).
resolution_cell='''resolution_stress_rows=[]
if RUN_RESOLUTION_STRESS:
    print("Resolution stress is an optional extension; enable only for release qualification or focused study.")
else:
    print("Resolution stress disabled on canonical Run all.")
'''
resolution=[]
for flag in (False,True):
    ns={'RUN_RESOLUTION_STRESS':flag}; stdout=io.StringIO()
    with contextlib.redirect_stdout(stdout): exec(resolution_cell,ns)
    resolution.append({'flag':flag,'result_rows':len(ns['resolution_stress_rows']),'stdout':stdout.getvalue().strip()})
assert all(x['result_rows']==0 for x in resolution)
record('resolution_stress_control_noop',{'kind':'reproduced defect','outcomes':resolution})

# The default data-efficiency cell's nested subsets and its access to test data.
part=[{'source_id':f'class{c}-{i:02d}','label_id':c} for c in range(6) for i in range(18)]
idx=[nb.nested_train_indices(part,n) for n in [6,12,18]]
assert list(map(len,idx))==[36,72,108] and set(idx[0])<=set(idx[1])<=set(idx[2])
class NoTest(dict):
    def __getitem__(self,key):
        if key=='test': raise RuntimeError('TEST_INPUT_ACCESSED_DURING_ACTIVITY')
        return super().__getitem__(key)
ns={'RUN_DATA_EFFICIENCY':True,'DATA_EFFICIENCY_PER_CLASS':[6],
    'nested_train_indices':nb.nested_train_indices,'splits':{'train':part},
    'ALL_RESULTS':{'fixture':{'model':'synthetic'}},
    'ALL_FEATURES':{'fixture':NoTest(train={'features':np.zeros((108,6)),'labels':np.array([r['label_id'] for r in part])},
                                    validation={'features':np.zeros((12,6)),'labels':np.repeat(np.arange(6),2)})},
    'fit_probe':nb.fit_probe}
activity_prefix='''for per_class in DATA_EFFICIENCY_PER_CLASS:
    idx=nested_train_indices(splits["train"],per_class)
    for key,r in ALL_RESULTS.items():
        feat=ALL_FEATURES[key]
        probe=fit_probe(
            feat["train"]["features"][idx],feat["train"]["labels"][idx],
            feat["validation"]["features"],feat["validation"]["labels"],
            feat["test"]["features"],
        )
'''
error=expect_error(lambda:exec(activity_prefix,ns))
record('data_efficiency_activity_boundary',{'kind':'positive structure and reproduced boundary mismatch',
 'subset_sizes':list(map(len,idx)),'nested':True,'validation_only_sentinel':error,
 'note':'The notebook subsequently scores and prints test accuracy; no vision backbone was run here.'})

# PCA plot lifecycle. Same save/close path on synthetic already-standardized features.
plt.close('all'); rng=np.random.default_rng(2026)
tr=rng.normal(size=(36,8)).astype(np.float32); te=rng.normal(size=(12,8)).astype(np.float32)
_,_,(tr,te)=nb.standardize_from_train(tr,te)
tr_center=tr-tr.mean(axis=0,keepdims=True)
_u,_s,vt=np.linalg.svd(tr_center,full_matrices=False)
te2=(te-tr.mean(axis=0,keepdims=True))@vt[:2].T
fig=plt.figure(figsize=(7,5)); ax=fig.add_subplot(111)
labels=np.repeat(np.arange(6),2)
for class_id,label in enumerate(nb.CLASS_KEYS):
    mask=labels==class_id; ax.scatter(te2[mask,0],te2[mask,1],label=label,alpha=.8)
ax.set_title('Synthetic probe — train-fitted PCA of test features')
ax.set_xlabel('PC1'); ax.set_ylabel('PC2'); ax.legend(fontsize=7); fig.tight_layout()
plot=RESULTS/'pca_saved_only_synthetic.png'; fig.savefig(plot,dpi=140); plt.close(fig)
assert plot.is_file() and len(plt.get_fignums())==0
record('pca_output_lifecycle',{'kind':'reproduced output behavior','saved_png_exists':True,
 'open_figures_at_cell_end':len(plt.get_fignums()),'inline_display_call_in_transcribed_cell':False,
 'note':'Local Agg lifecycle check; not a Colab UI execution.'})

# Fault injection is recorded as robustness evidence, not evidence of bad live predictions.
invalid=np.full((6,6),2.0)
m=nb.classification_metrics(np.arange(6),invalid)
assert m['log_loss']<0
length_error=expect_error(lambda:nb.classification_metrics(np.arange(6),invalid[:5]))
record('metric_probability_validation',{'kind':'robustness gap plus positive control',
 'invalid_probability_rows_accepted':True,'log_loss':m['log_loss'],
 'row_count_mismatch_rejected':length_error})

output={'source_commit':'cf3dbadaade69dd320b6018832646601a2cd4df9',
 'source_blob':'3083a52e48b7ae97523fb6073b3ba371e816c5fe',
 'basis':'Manually transcribed helpers and synthetic fixtures; not whole-notebook execution.',
 'runtime':{'python':platform.python_version(),**{k:importlib.metadata.version(k) for k in ['numpy','Pillow','torch','safetensors','matplotlib']}},
 'pretrained_backbones_executed':False,'colab_execution':False,'check_groups':len(records),'checks':records}
(RESULTS/'probe_results.json').write_text(json.dumps(output,indent=2,allow_nan=False),encoding='utf-8')
print(json.dumps(output,indent=2,allow_nan=False))
