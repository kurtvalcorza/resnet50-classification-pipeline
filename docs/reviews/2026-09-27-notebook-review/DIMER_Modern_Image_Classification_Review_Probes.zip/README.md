# Modern Image Classification — Offline Review Probes

Source repository: `kurtvalcorza/resnet50-classification-pipeline`  
Source commit: `cf3dbadaade69dd320b6018832646601a2cd4df9`  
Notebook: `tutorials/DIMER_Modern_Image_Classification_Workshop.ipynb`  
Reported Git blob: `3083a52e48b7ae97523fb6073b3ba371e816c5fe`

## Scope

These are manually transcribed helper and cell excerpts, with synthetic fixtures.
They are not a downloaded byte-identical notebook and do not run its installation
cells or pretrained backbones. Formatting in the excerpt module is condensed;
small fixture support (imports/constants and a file hashing helper) is supplied locally.

The harness records 16 grouped checks, including positive controls, intentional
fault injections, and expected failures. A successful harness run means the
reported behaviors were reproduced; it does not mean the notebook passed acceptance.

The actual local environment is recorded in `results/probe_results.json`.
It differs from the notebook's pinned hosted environment. CPU PyTorch is used
for real small linear-probe fitting and SafeTensors reload, but all feature vectors
are synthetic. No visual representation quality or whole-Colab execution is tested.

## Run

With Python, NumPy, Pillow, PyTorch, SafeTensors, and matplotlib available:

```bash
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python run_probes.py
```

The script creates temporary image/ZIP fixtures and deletes them after the checks.
All traversal/containment fixtures reference harmless files inside the same temporary
review directory. There are no real-user files, pretrained weights, external calls,
repository writes, or destructive operations outside that temporary workspace.

Results are written to `results/probe_results.json`. The supplied `run_log.txt`
is the stdout captured from the reviewed run. `pca_saved_only_synthetic.png` is a
synthetic plot-lifecycle illustration, not a screenshot of the source notebook.

## Contents

- `notebook_excerpts.py`: Transcribed selected notebook logic and fixture support.
- `run_probes.py`: Reproducible fixtures, checks, assertions, and result recording.
- `results/probe_results.json`: Structured observations and environment.
- `results/run_log.txt`: Captured execution result.
- `results/pca_saved_only_synthetic.png`: Synthetic PCA save/close illustration.
- `source_and_file_manifest.json`: Source identity and hashes of bundle files.

Interpret these checks alongside the separate Markdown review. Changes in a newer
notebook revision must be checked against its actual source; this harness does not
claim applicability to arbitrary subsequent revisions.
