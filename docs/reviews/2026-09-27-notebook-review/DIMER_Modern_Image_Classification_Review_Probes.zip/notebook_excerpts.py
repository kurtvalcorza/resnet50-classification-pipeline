"""Manually transcribed review excerpts, not a downloaded notebook.

Source: kurtvalcorza/resnet50-classification-pipeline at
cf3dbadaade69dd320b6018832646601a2cd4df9,
tutorials/DIMER_Modern_Image_Classification_Workshop.ipynb.
Relevant cells: f370927c, 6e025182, 71cf319a, f3c4811d, 23084f05.
Only imports/constants needed by these excerpts were added. No backbone code
or package installation is executed. Test fixtures set CLASS_KEYS and OUT_ROOT.
"""
import csv, hashlib, io, json, random, time, zipfile
from pathlib import Path
import numpy as np
from PIL import Image
import torch
import torch.nn.functional as F
from safetensors.torch import save_file, load_file
CLASS_KEYS = ['song_sparrow','chipping_sparrow','white_throated_sparrow','dark_eyed_junco','house_finch','american_goldfinch']
PROBE_EPOCHS=1000
PROBE_LR=0.001
PROBE_WEIGHT_DECAY=1e-4
OUT_ROOT=Path('outputs')

def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()
def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def image_digest(image):
    rgb = image.convert("RGB")
    return sha256_bytes(f"{rgb.width}x{rgb.height}:".encode() + rgb.tobytes())

def confusion_matrix_np(y_true,y_pred,n_classes=6):
    cm = np.zeros((n_classes,n_classes),dtype=int)
    for t,p in zip(y_true,y_pred,strict=True):
        cm[int(t),int(p)] += 1
    return cm

def class_metrics(cm):
    rows=[]
    for i in range(cm.shape[0]):
        tp=cm[i,i]; fp=cm[:,i].sum()-tp; fn=cm[i,:].sum()-tp
        support=cm[i,:].sum()
        precision=tp/(tp+fp) if tp+fp else 0.0
        recall=tp/(tp+fn) if tp+fn else 0.0
        f1=2*precision*recall/(precision+recall) if precision+recall else 0.0
        rows.append({"class_id":i,"class_label":CLASS_KEYS[i],"support":int(support),
                     "precision":float(precision),"recall":float(recall),"f1":float(f1)})
    return rows

def classification_metrics(y_true, probs):
    y_true=np.asarray(y_true,dtype=int)
    probs=np.asarray(probs,dtype=float)
    pred=probs.argmax(axis=1)
    cm=confusion_matrix_np(y_true,pred,len(CLASS_KEYS))
    per=class_metrics(cm)
    top3=np.argsort(-probs,axis=1)[:,:3]
    log_loss=float(-np.mean(np.log(np.maximum(probs[np.arange(len(y_true)),y_true],1e-12))))
    return {
        "accuracy":float(np.mean(pred==y_true)),
        "macro_f1":float(np.mean([r["f1"] for r in per])),
        "top3_accuracy":float(np.mean([y_true[i] in top3[i] for i in range(len(y_true))])),
        "log_loss":log_loss,"confusion_matrix":cm,"per_class":per,"predicted_ids":pred,
    }

def standardize_from_train(train_x,*others):
    mean=train_x.mean(axis=0,keepdims=True).astype(np.float32)
    std=train_x.std(axis=0,keepdims=True).astype(np.float32)
    std=np.maximum(std,1e-6)
    return mean,std,[(x-mean)/std for x in (train_x,*others)]

def knn_predict(train_x,train_y,test_x,k=5):
    train_n=train_x/np.maximum(np.linalg.norm(train_x,axis=1,keepdims=True),1e-12)
    test_n=test_x/np.maximum(np.linalg.norm(test_x,axis=1,keepdims=True),1e-12)
    sims=test_n@train_n.T
    predictions=[]; probs=[]
    for row in sims:
        idx=np.argsort(-row,kind="stable")[:k]
        vote_counts=np.zeros(len(CLASS_KEYS),dtype=int)
        sim_sums=np.zeros(len(CLASS_KEYS),dtype=float)
        for j in idx:
            c=int(train_y[j]); vote_counts[c]+=1; sim_sums[c]+=float(row[j])
        order=sorted(range(len(CLASS_KEYS)), key=lambda c:(-vote_counts[c],-sim_sums[c],c))
        predictions.append(order[0])
        p=vote_counts.astype(float)
        p=p/p.sum()
        probs.append(p)
    return np.array(predictions),np.array(probs,dtype=np.float32)

def generic_knn_predict(train_x,train_y,test_x,n_classes,k=5):
    train_n=train_x/np.maximum(np.linalg.norm(train_x,axis=1,keepdims=True),1e-12)
    test_n=test_x/np.maximum(np.linalg.norm(test_x,axis=1,keepdims=True),1e-12)
    sims=test_n@train_n.T
    probs=[]
    for row in sims:
        idx=np.argsort(-row,kind="stable")[:min(k,len(train_y))]
        counts=np.zeros(n_classes,dtype=int)
        sim_sums=np.zeros(n_classes,dtype=float)
        for j in idx:
            c=int(train_y[j]); counts[c]+=1; sim_sums[c]+=float(row[j])
        order=sorted(range(n_classes),key=lambda c:(-counts[c],-sim_sums[c],c))
        p=counts.astype(float)
        p=p/p.sum()
        probs.append(p)
    return np.asarray(probs,dtype=np.float32)

def fit_probe(train_x,train_y,val_x,val_y,test_x,
              epochs=PROBE_EPOCHS,lr=PROBE_LR,weight_decay=PROBE_WEIGHT_DECAY):
    mean,std,(tr,va,te)=standardize_from_train(train_x,val_x,test_x)
    xtr=torch.from_numpy(tr.astype(np.float32))
    ytr=torch.from_numpy(np.asarray(train_y,dtype=np.int64))
    xva=torch.from_numpy(va.astype(np.float32))
    yva=torch.from_numpy(np.asarray(val_y,dtype=np.int64))
    xte=torch.from_numpy(te.astype(np.float32))
    layer=torch.nn.Linear(tr.shape[1],len(CLASS_KEYS))
    torch.nn.init.zeros_(layer.weight); torch.nn.init.zeros_(layer.bias)
    opt=torch.optim.AdamW(layer.parameters(),lr=lr,weight_decay=weight_decay)
    best_loss=float("inf"); best_epoch=None; best_state=None
    start=time.perf_counter()
    for epoch in range(1,epochs+1):
        layer.train(); opt.zero_grad(set_to_none=True)
        loss=F.cross_entropy(layer(xtr),ytr)
        loss.backward(); opt.step(); layer.eval()
        with torch.inference_mode():
            val_loss=float(F.cross_entropy(layer(xva),yva))
        if val_loss < best_loss - 1e-12:
            best_loss=val_loss; best_epoch=epoch
            best_state={k:v.detach().clone() for k,v in layer.state_dict().items()}
    training_seconds=time.perf_counter()-start
    layer.load_state_dict(best_state); layer.eval()
    with torch.inference_mode():
        test_probs=torch.softmax(layer(xte),dim=1).numpy().astype(np.float32)
        val_probs=torch.softmax(layer(xva),dim=1).numpy().astype(np.float32)
    return {"layer":layer,"mean":mean.squeeze(0),"std":std.squeeze(0),
            "best_epoch":best_epoch,"validation_loss":best_loss,
            "selected_at_first_epoch":best_epoch==1,"selected_at_epoch_cap":best_epoch==epochs,
            "test_probs":test_probs,"val_probs":val_probs,"training_seconds":training_seconds}

def save_probe_artifact(key,spec,probe,feature_dim,train_digest,val_digest):
    root=OUT_ROOT/"probes"/key
    root.mkdir(parents=True,exist_ok=True)
    path=root/"probe.safetensors"
    tensors={"classifier.weight":probe["layer"].weight.detach().cpu().contiguous(),
             "classifier.bias":probe["layer"].bias.detach().cpu().contiguous(),
             "feature_mean":torch.from_numpy(probe["mean"]).contiguous(),
             "feature_std":torch.from_numpy(probe["std"]).contiguous()}
    save_file(tensors,str(path))
    base_sha=next(x["sha256"] for x in spec["manifest"]["files"] if x["path"]=="model.safetensors")
    manifest={"format":"dimer_linear_probe","format_version":1,
              "base_model_id":spec["manifest"]["modelId"],"base_model_revision":spec["manifest"]["revision"],
              "base_weight_sha256":base_sha,"feature_interface":"pre_logits","feature_dim":feature_dim,
              "class_order":CLASS_KEYS,
              "probe":{"best_epoch":probe["best_epoch"],"optimizer":"AdamW","learning_rate":PROBE_LR,"weight_decay":PROBE_WEIGHT_DECAY},
              "training_sample_digest":train_digest,"validation_sample_digest":val_digest,
              "probe_file":{"bytes":path.stat().st_size,"sha256":sha256_file(path)}}
    (root/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    return path,manifest

def reload_probe_verify(path,manifest,spec,test_x,reference_probs):
    base_sha=next(x["sha256"] for x in spec["manifest"]["files"] if x["path"]=="model.safetensors")
    if manifest["base_model_id"] != spec["manifest"]["modelId"] or manifest["base_model_revision"] != spec["manifest"]["revision"]:
        raise RuntimeError("Probe/base model identity mismatch")
    if manifest["base_weight_sha256"] != base_sha:
        raise RuntimeError("Probe/base weight digest mismatch")
    state=load_file(str(path),device="cpu")
    dim=int(manifest["feature_dim"])
    if test_x.shape[1] != dim:
        raise RuntimeError("Probe feature dimension mismatch")
    fresh=torch.nn.Linear(dim,len(CLASS_KEYS))
    fresh.load_state_dict({"weight":state["classifier.weight"],"bias":state["classifier.bias"]})
    mean=state["feature_mean"].numpy(); std=state["feature_std"].numpy()
    x=torch.from_numpy(((test_x-mean)/std).astype(np.float32))
    fresh.eval()
    with torch.inference_mode():
        probs=torch.softmax(fresh(x),dim=1).numpy()
    diff=float(np.max(np.abs(probs-reference_probs)))
    if diff > 1e-6 or not np.array_equal(probs.argmax(1),reference_probs.argmax(1)):
        raise RuntimeError(f"Probe reload parity failed: max diff {diff}")
    return diff

BYOD_EXTENSIONS={".jpg",".jpeg",".png",".webp",".tif",".tiff",".bmp"}
def load_byod_explicit(path):
    source=Path(path)
    if source.is_file() and source.suffix.lower()==".zip":
        root=Path("byod_modern_image"); root.mkdir(exist_ok=True)
        with zipfile.ZipFile(source) as zf:
            expanded=0
            for info in zf.infolist():
                name=info.filename.replace("\\","/")
                parts=[p for p in name.split("/") if p]
                if info.is_dir(): continue
                if name.startswith("/") or ".." in parts:
                    raise ValueError(f"Unsafe ZIP member: {name}")
                mode=(info.external_attr>>16)&0o170000
                if mode==0o120000: raise ValueError(f"Symlink ZIP member refused: {name}")
                expanded+=info.file_size
                if expanded>1_000_000_000: raise ValueError("BYOD ZIP exceeds 1 GB expanded")
                target=root/Path(name).name
                target.write_bytes(zf.read(info))
    elif source.is_dir(): root=source
    else: raise ValueError("BYOD_PATH must be a directory or ZIP")
    table=root/"labels.csv"
    if not table.is_file(): raise ValueError("BYOD requires labels.csv")
    rows=list(csv.DictReader(table.open(encoding="utf-8",newline="")))
    required={"filename","label","split"}
    if not rows or not required.issubset(rows[0]):
        raise ValueError("labels.csv must contain filename,label,split")
    allowed={"train","validation","test"}
    labels=sorted({r["label"].strip() for r in rows})
    if not 2<=len(labels)<=20: raise ValueError("BYOD must contain 2..20 classes")
    label_to_id={label:i for i,label in enumerate(labels)}
    out={k:[] for k in allowed}; pixel_seen={}
    for i,row in enumerate(rows):
        split=row["split"].strip().lower()
        if split not in allowed: raise ValueError(f"Unknown split {split!r}")
        filename=row["filename"].strip(); p=root/filename
        if p.suffix.lower() not in BYOD_EXTENSIONS or not p.is_file():
            raise ValueError(f"Unsupported/missing image {filename}")
        image=Image.open(p); image.load(); image=image.convert("RGB")
        pix=image_digest(image)
        if pix in pixel_seen and pixel_seen[pix] != split:
            raise ValueError(f"Duplicate decoded image crosses splits: {filename}")
        pixel_seen[pix]=split; label=row["label"].strip()
        out[split].append({"id":f"{split}-{i:04d}","source_id":filename,"split":split,
                           "label":label,"label_id":label_to_id[label],"image":image,"pixel_sha256":pix})
    for label in labels:
        counts={split:sum(r["label"]==label for r in out[split]) for split in allowed}
        if counts["train"]<10 or counts["validation"]<2 or counts["test"]<2:
            raise ValueError(f"{label}: insufficient explicit split counts {counts}")
    total=sum(map(len,out.values()))
    if not 60<=total<=600: raise ValueError("BYOD must contain 60..600 images")
    return out,labels

def nested_train_indices(part,per_class):
    selected=[]
    for class_id in range(len(CLASS_KEYS)):
        candidates=[(r["source_id"],i) for i,r in enumerate(part) if r["label_id"]==class_id]
        candidates.sort()
        selected.extend(i for _sid,i in candidates[:per_class])
    return sorted(selected)
