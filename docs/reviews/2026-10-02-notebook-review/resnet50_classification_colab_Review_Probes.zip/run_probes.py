"""Row 75 probes: resnet50-classification-pipeline tutorials/resnet50_classification_colab.ipynb.

Direct execution on local CPU (CUDA_VISIBLE_DEVICES=-1) with the notebook's own code cells exec'd in one
namespace, cwd = a scratch run directory. The install cell runs with DIMER_NOTEBOOK_CI_PREINSTALLED=1 (its own
skip switch) in a venv whose versions equal PINS (CPU wheels; torchaudio absent, unused by the notebook).
The pinned snapshot is pre-copied into weights/resnet50-a1/ from a local verified copy (verify_snapshot still
re-hashes every file), so the Hub download stage is NOT exercised. The CIFAR-10 subset is downloaded for real.
Usage: python run_probes.py <notebook.ipynb> <scratch_dir> <local_weights_dir>
"""
import contextlib, copy, hashlib, io, json, os, shutil, sys, time, traceback, types, zipfile

NB, SCRATCH, LOCAL_WEIGHTS = sys.argv[1], sys.argv[2], sys.argv[3]
assert os.environ.get('CUDA_VISIBLE_DEVICES') == '-1'
os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
OUT = os.path.join(SCRATCH, 'results.json')
results = {'env': {}, 'static': {}, 'default': {}, 'active': {}, 'reuse': {}}

def save():
    with open(OUT, 'w', encoding='utf-8') as fh:
        json.dump(results, fh, indent=1, default=str)

nb = json.load(open(NB, encoding='utf-8'))
cells = nb['cells']
code = {i: ''.join(c['source']) for i, c in enumerate(cells) if c['cell_type'] == 'code'}
md = '\n'.join(''.join(c['source']) for c in cells if c['cell_type'] == 'markdown')

# ---------- static ----------
low = md.lower()
results['static'] = {
    'n_cells': len(cells), 'code_cells': sorted(code),
    'metadata_dimer': nb['metadata'].get('dimer'),
    'guided_layer_hits': {k: low.count(k) for k in ['predict', 'checkpoint', 'glossary', 'troubleshoot', 'roadmap',
                          'how to use', 'infrastructure', 'what to notice', 'expected result', 'try ', 'sample answer',
                          'your turn', 'exercise', 'reflect']},
    'SAMPLE_HEIGHT_defined_anywhere': any(('SAMPLE_HEIGHT =' in s or 'SAMPLE_HEIGHT=' in s) for s in code.values()),
    'SAMPLE_HEIGHT_used_in_cell': [i for i, s in code.items() if 'SAMPLE_HEIGHT' in s],
    'fine_tuned_pipe_uses': sum(s.count('fine_tuned_pipe') for s in code.values()),
    'fit_trains_all_params': 'AdamW(model.parameters()' in code[5],
    'prose_head_only_claims': [p for p in ['head adaptation', 'classification head fine-tuning', 'new linear classifier'] if p in md],
    'torchaudio_imported': any('torchaudio' in s for i, s in code.items() if i != 3),
    'upload_cells': [i for i, s in code.items() if 'google.colab' in s],
}
save()

# ---------- helpers ----------
class FakeFiles:
    payload = None
    @staticmethod
    def upload():
        if FakeFiles.payload is None:
            raise RuntimeError('no payload')
        return dict(FakeFiles.payload)

def install_colab_shim():
    g = types.ModuleType('google'); g.__path__ = []
    c = types.ModuleType('google.colab'); c.files = FakeFiles
    sys.modules['google'] = g; sys.modules['google.colab'] = c

def remove_colab_shim():
    sys.modules.pop('google.colab', None); sys.modules.pop('google', None)

def run_cell(ns, i, timings=None):
    t = time.time()
    exec(compile(code[i], f'cell{i}', 'exec'), ns)
    if timings is not None:
        timings[i] = round(time.time() - t, 2)

def edited(i, **repl):
    s = code[i]
    for k, v in repl.items():
        old = [ln for ln in s.splitlines() if ln.startswith(k + ' =')][0]
        s = s.replace(old, f'{k} = {v!r}', 1)
    return s

def exec_src(ns, src, name):
    exec(compile(src, name, 'exec'), ns)

def err(e):
    return f'{type(e).__name__}: {e}'[:400]

def png(color, size=(40, 40)):
    from PIL import Image
    b = io.BytesIO(); Image.new('RGB', size, color).save(b, 'PNG'); return b.getvalue()

def make_zip(entries):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        for name, data in entries.items():
            z.writestr(name, data)
    return b.getvalue()

# ---------- default journey ----------
run_dir = os.path.join(SCRATCH, 'run_default')
shutil.rmtree(run_dir, ignore_errors=True); os.makedirs(os.path.join(run_dir, 'weights', 'resnet50-a1'))
for f in ['README.md', 'config.json', 'model.safetensors']:
    shutil.copy2(os.path.join(LOCAL_WEIGHTS, f), os.path.join(run_dir, 'weights', 'resnet50-a1', f))
os.chdir(run_dir)
ns = {'__name__': '__main__'}
timings = {}
t0 = time.time()
try:
    for i in sorted(code):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            run_cell(ns, i, timings)
        results['default'].setdefault('stdout_tail', {})[i] = buf.getvalue()[-1500:]
    results['default']['status'] = 'ok'
except Exception as e:
    results['default']['status'] = 'error'; results['default']['error'] = err(e); results['default']['tb'] = traceback.format_exc()[-2000:]
results['default']['timings_s'] = timings
results['default']['wall_s'] = round(time.time() - t0, 1)
save()

import numpy as np, torch
from safetensors.torch import load_file
r = results['default']
if r['status'] == 'ok':
    r['env'] = {'python': sys.version.split()[0], 'torch': torch.__version__, 'timm': ns['timm'].__version__, 'numpy': np.__version__, 'device': ns['pipe'].device}
    r['prediction_top5'] = [(it['index'], round(it['score'], 4), it['label']) for it in ns['prediction']['top_k']]
    r['eval_verdict'] = ns['report']['verdict']
    r['dataset_source'] = ns['dataset_source']
    r['classes'] = ns['CUSTOM_CLASSES']; r['n_train'] = len(ns['train_images']); r['n_val'] = len(ns['val_images'])
    r['history'] = ns['train_meta']['history']
    r['finetuned_metrics'] = ns['finetuned_eval_report']['metrics']; r['finetuned_verdict'] = ns['finetuned_eval_report']['verdict']
    r['per_class'] = ns['finetuned_eval_report']['per_class_breakdown']
    r['val_predictions'] = ns['val_predictions']
    r['outputs'] = sorted(os.listdir('outputs'))
    # dataset composition in the archive
    with zipfile.ZipFile(io.BytesIO(ns['zip_bytes'])) as z:
        names = [n for n in z.namelist() if n.lower().endswith(('.png', '.jpg', '.jpeg', '.webp', '.bmp')) and not n.startswith('__MACOSX')]
        comp = {}
        for n in names:
            parts = n.strip('/').split('/'); comp[parts[-2] if len(parts) >= 2 else 'unknown'] = comp.get(parts[-2] if len(parts) >= 2 else 'unknown', 0) + 1
        r['archive_composition'] = comp; r['archive_top_dirs'] = sorted({n.split('/')[0] for n in z.namelist()})[:10]
        r['archive_image_sizes'] = sorted({Image_size for Image_size in [__import__('PIL.Image', fromlist=['Image']).open(io.BytesIO(z.read(n))).size for n in names[:20]]})
    # near-duplicates across train/val (exact pixels and 8x8 mean-hash hamming <= 3)
    def ahash(im):
        a = np.asarray(im.convert('L').resize((8, 8))); return (a > a.mean()).flatten()
    tr = [ahash(im) for im in ns['train_images']]; va = [ahash(im) for im in ns['val_images']]
    trx = {hashlib.sha256(np.asarray(im).tobytes()).hexdigest() for im in ns['train_images']}
    r['val_exact_dups_in_train'] = sum(hashlib.sha256(np.asarray(im).tobytes()).hexdigest() in trx for im in ns['val_images'])
    r['val_min_ahash_hamming_to_train'] = [int(min((v != t).sum() for t in tr)) for v in va]
    # what fit trained: backbone vs base, BN stats
    base = load_file(os.path.join('weights', 'resnet50-a1', 'model.safetensors'))
    ft = load_file(os.path.join('outputs', 'resnet50_classification_finetuned', 'model.safetensors'))
    shared = [k for k in base if k in ft and base[k].shape == ft[k].shape]
    changed = [k for k in shared if not torch.equal(base[k], ft[k])]
    r['fit_params'] = {'shared_tensors': len(shared), 'changed_vs_base': len(changed),
                       'conv1_changed': 'conv1.weight' in changed,
                       'layer1_conv_changed': 'layer1.0.conv1.weight' in changed,
                       'bn1_running_mean_changed': 'bn1.running_mean' in changed,
                       'conv1_max_abs_delta': float((base['conv1.weight'] - ft['conv1.weight']).abs().max()),
                       'fc_shape': list(ft['fc.weight'].shape)}
    cfg = json.load(open(os.path.join('outputs', 'resnet50_classification_finetuned', 'model-config.json')))
    r['model_config_keys'] = sorted(cfg)
    res_json = json.load(open(os.path.join('outputs', 'resnet50_classification_result.json')))
    r['result_json_fine_tuning_keys'] = sorted(res_json['fine_tuning'])
    # VER4: in-memory fine-tuned vs reloaded outputs (the notebook never compares)
    ftp, rp = ns['fine_tuned_pipe'], ns['reloaded_pipe']
    diffs = []
    for im in ns['val_images']:
        a = ftp.predict(im, top_k=2)['predictions'][0]['top_k']; b = rp.predict(im, top_k=2)['predictions'][0]['top_k']
        diffs.append(max(abs(x['score'] - y['score']) for x, y in zip(sorted(a, key=lambda d: d['index']), sorted(b, key=lambda d: d['index']))))
    r['ver4_max_score_diff_inmemory_vs_reloaded'] = max(diffs)
    save()

    # ---------- active learning ----------
    a = results['active']
    pred_before = [it['index'] for it in ns['prediction']['top_k']]
    run_cell(ns, 13)
    a['cell13_rerun_after_fit_same_top5'] = [it['index'] for it in ns['prediction']['top_k']] == pred_before
    acc1 = ns['finetuned_eval_report']['metrics']['accuracy']
    with contextlib.redirect_stdout(io.StringIO()):
        run_cell(ns, 17); run_cell(ns, 19)
    a['rerun_17_19_same_accuracy'] = (acc1, ns['finetuned_eval_report']['metrics']['accuracy'])
    a['rerun_history'] = ns['train_meta']['history']
    # documented next experiment surrogate: GROUND_TRUTH_INDEX on the default gradient (single-image BYOD form path)
    with contextlib.redirect_stdout(io.StringIO()):
        exec_src(ns, edited(9, GROUND_TRUTH_INDEX=ns['prediction']['predicted_index']), 'cell9_gt'); run_cell(ns, 11); run_cell(ns, 13); run_cell(ns, 15)
    a['gt_index_report'] = {'verdict': ns['report']['verdict'], 'metrics': ns['report']['metrics']}
    # bounded change: epochs=3 instead of 1 (a natural "change one thing"); not offered as a form field
    src17 = code[17].replace('    epochs=1,', '    epochs=3,')
    with contextlib.redirect_stdout(io.StringIO()):
        t = time.time(); exec_src(ns, src17, 'cell17_epochs3'); run_cell(ns, 19)
    a['epochs3'] = {'history': ns['train_meta']['history'], 'metrics': ns['finetuned_eval_report']['metrics'], 'wall_s': round(time.time() - t, 1)}
    save()

    # ---------- reuse & recovery ----------
    u = results['reuse']
    def byod(label, entries, raw=None):
        install_colab_shim()
        FakeFiles.payload = raw if raw is not None else {'data.zip': make_zip(entries)}
        out = {}
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):
                exec_src(ns, edited(17, USE_BYOD_DATASET=True), f'byod_{label}_17')
            out['fit'] = 'ok'; out['classes'] = ns['CUSTOM_CLASSES']; out['n_train'] = len(ns['train_images']); out['n_val'] = len(ns['val_images'])
            out['val_targets'] = list(ns['val_targets']); out['train_targets'] = list(ns['train_targets'])
            try:
                with contextlib.redirect_stdout(io.StringIO()):
                    run_cell(ns, 19)
                out['eval'] = 'ok'; out['metrics'] = ns['finetuned_eval_report']['metrics']; out['per_class'] = ns['finetuned_eval_report']['per_class_breakdown']
            except Exception as e:
                out['eval'] = err(e)
        except Exception as e:
            out['fit'] = err(e)
        u[label] = out; save()

    red, blue, green = (200, 30, 30), (30, 30, 200), (30, 200, 30)
    byod('unsplit_2x4', {f'data/{c}/{k}.png': png(col) for c, col in [('cat', red), ('dog', blue)] for k in range(4)})
    byod('explicit_train_val', {**{f'train/{c}/{k}.png': png(col) for c, col in [('cat', red), ('dog', blue)] for k in range(3)},
                                **{f'val/{c}/{k}.png': png(col) for c, col in [('cat', red), ('dog', blue)] for k in range(1)}})
    byod('val_class_not_in_train', {**{f'train/{c}/{k}.png': png(col) for c, col in [('cat', red), ('dog', blue)] for k in range(3)},
                                    **{f'val/{c}/{k}.png': png(col) for c, col in [('cat', red), ('bird', green)] for k in range(2)}})
    byod('train_test_layout', {**{f'train/{c}/{k}.png': png(col) for c, col in [('cat', red), ('dog', blue)] for k in range(3)},
                               **{f'test/{c}/{k}.png': png(col) for c, col in [('cat', red), ('dog', blue)] for k in range(2)}})
    byod('explicit_one_image_class', {**{'train/cat/0.png': png(red), 'train/dog/0.png': png(blue)},
                                      **{'val/cat/0.png': png(red)}})
    byod('one_class', {f'data/cat/{k}.png': png(red) for k in range(4)})
    byod('class_with_1_image', {'data/cat/0.png': png(red), **{f'data/dog/{k}.png': png(blue) for k in range(3)}})
    byod('oversized_training_image', {**{f'data/cat/{k}.png': png(red, (4200, 8)) for k in range(3)}, **{f'data/dog/{k}.png': png(blue) for k in range(3)}})
    byod('corrupt_image', {'data/cat/0.png': b'not an image', 'data/cat/1.png': png(red), **{f'data/dog/{k}.png': png(blue) for k in range(2)}})
    byod('path_traversal', {'../evil/0.png': png(red)})
    byod('not_zip', None, raw={'data.tar': b'xx'})
    # interval/ folder name triggers 'val/' substring detection
    byod('substring_val_detection', {**{f'train/{c}/{k}.png': png(col) for c, col in [('cat', red), ('dog', blue)] for k in range(3)},
                                     'extra/interval/0.png': png(green)})
    # upload without Colab (Jupyter/Kaggle without shim)
    remove_colab_shim()
    try:
        exec_src(ns, edited(17, USE_BYOD_DATASET=True), 'byod_nocolab')
        u['upload_without_colab'] = 'no error'
    except Exception as e:
        u['upload_without_colab'] = err(e)
    try:
        exec_src(ns, edited(9, USE_BYOD=True), 'byod_img_nocolab')
        u['single_image_upload_without_colab'] = 'no error'
    except Exception as e:
        u['single_image_upload_without_colab'] = err(e)
    # sample-dataset download failure / digest mismatch -> advertised synthetic fallback
    for label, repl in [('download_failure', {'SAMPLE_DATASET_URL': 'https://huggingface.co/datasets/does-not-exist/x/resolve/0/none.zip'}),
                        ('digest_mismatch', {'SAMPLE_DATASET_SHA256': '0' * 64})]:
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):
                exec_src(ns, edited(17, **repl), f'fallback_{label}')
            u[label] = {'result': 'ok', 'dataset_source': ns['dataset_source']}
        except Exception as e:
            u[label] = {'result': err(e)}
        u[label]['printed'] = buf.getvalue()[-400:]
        save()
    # single-image BYOD rejection: oversized image through validate cell
    install_colab_shim()
    FakeFiles.payload = {'big.png': png(red, (4200, 10))}
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            exec_src(ns, edited(9, USE_BYOD=True), 'byod_img_big'); run_cell(ns, 11)
        u['single_image_oversized'] = 'accepted'
    except Exception as e:
        u['single_image_oversized'] = err(e)
    FakeFiles.payload = {'ok.png': png(red, (300, 200))}
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            exec_src(ns, edited(9, USE_BYOD=True, GROUND_TRUTH_INDEX=5), 'byod_img_ok'); run_cell(ns, 11); run_cell(ns, 13); run_cell(ns, 15)
        u['single_image_ok'] = {'verdict': ns['report']['verdict'], 'metrics': ns['report']['metrics']}
    except Exception as e:
        u['single_image_ok'] = err(e)
results['total_wall_s'] = round(time.time() - t0, 1)
save()
print('done', results['total_wall_s'])
